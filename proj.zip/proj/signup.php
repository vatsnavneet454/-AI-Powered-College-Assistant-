<?php
// --- SESSION MANAGEMENT ---
session_start();

if (isset($_SESSION['id'])) {
    header("Location: dashboard.php");
    exit();
}

require_once 'db.php';

$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize all inputs
    $registration_id = $conn->real_escape_string(trim($_POST['registration_id']));
    $name = $conn->real_escape_string(trim($_POST['name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $role = $_POST['role'];
    
    // Role-specific fields
    $course = ($role === 'student') ? $conn->real_escape_string(trim($_POST['course'])) : NULL;
    $subjects = $conn->real_escape_string(trim($_POST['subjects']));

    // --- FORM VALIDATION ---
    if (empty($registration_id) || empty($name) || empty($email) || empty($password) || empty($role)) {
        $error_message = "Please fill in all required fields.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } elseif ($role === 'student' && empty($course)) {
        $error_message = "Please select a course.";
    } else {
        // Check if registration ID or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE registration_id = ? OR email = ?");
        $stmt->bind_param("ss", $registration_id, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error_message = "Registration ID or Email already exists.";
        } else {
            // Hash password and insert user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO users (registration_id, name, email, password, role, course, subjects) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $insert_stmt->bind_param("sssssss", $registration_id, $name, $email, $hashed_password, $role, $course, $subjects);

            if ($insert_stmt->execute()) {
                // If the new user is a teacher, also add them to the faculty table
                if ($role === 'teacher') {
                    $faculty_stmt = $conn->prepare("INSERT INTO faculty (name, email) VALUES (?, ?)");
                    $faculty_stmt->bind_param("ss", $name, $email);
                    $faculty_stmt->execute();
                    $faculty_stmt->close();
                }
                $success_message = "Account created successfully! You can now <a href='login.php' class='font-bold text-indigo-600 hover:underline'>log in</a>.";
            } else {
                $error_message = "Error: Could not create account.";
            }
            $insert_stmt->close();
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100">
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4">
            <a href="index.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
        </nav>
    </header>

    <main class="flex justify-center items-center py-12 px-4">
        <div class="w-full max-w-lg bg-white p-8 rounded-lg shadow-md">
            <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Create Your Account</h2>
            
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded-md mb-4"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded-md mb-4"><?php echo $success_message; ?></div>
            <?php endif; ?>

            <form action="signup.php" method="POST" class="space-y-4">
                <!-- Common Fields -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="registration_id" class="block text-sm font-medium text-gray-700">Registration ID</label>
                        <input type="text" id="registration_id" name="registration_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700">Full Name</label>
                        <input type="text" id="name" name="name" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                </div>
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" id="email" name="email" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                        <input type="password" id="password" name="password" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label for="confirm_password" class="block text-sm font-medium text-gray-700">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                </div>
                
                <!-- Role Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">I am a...</label>
                    <div class="flex items-center space-x-4 mt-2">
                        <label><input type="radio" name="role" value="student" checked onchange="toggleFields()"> Student</label>
                        <label><input type="radio" name="role" value="teacher" onchange="toggleFields()"> Teacher</label>
                    </div>
                </div>

                <!-- Role-Specific Fields -->
                <div id="student-fields" class="space-y-4">
                    <div>
                        <label for="course" class="block text-sm font-medium text-gray-700">Course</label>
                        <select id="course" name="course" class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                            <option value="">Select your course</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Business Administration">Business Administration</option>
                            <option value="Mechanical Engineering">Mechanical Engineering</option>
                        </select>
                    </div>
                    <div>
                        <label for="student_subjects" class="block text-sm font-medium text-gray-700">Your Subjects</label>
                        <input type="text" id="student_subjects" name="subjects" placeholder="e.g., Math, Physics, Chemistry" class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                </div>

                <div id="teacher-fields" class="hidden space-y-4">
                     <div>
                        <label for="teacher_subjects" class="block text-sm font-medium text-gray-700">Subjects You Teach</label>
                        <input type="text" id="teacher_subjects" name="subjects" placeholder="e.g., Data Structures, Algorithms" class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                </div>
                
                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-md">Create Account</button>
            </form>
        </div>
    </main>

    <script>
        function toggleFields() {
            const role = document.querySelector('input[name="role"]:checked').value;
            const studentFields = document.getElementById('student-fields');
            const teacherFields = document.getElementById('teacher-fields');
            const studentSubjects = document.getElementById('student_subjects');
            const teacherSubjects = document.getElementById('teacher_subjects');
            const course = document.getElementById('course');

            if (role === 'student') {
                studentFields.classList.remove('hidden');
                teacherFields.classList.add('hidden');
                // Use different name attributes to submit the correct subjects
                studentSubjects.name = 'subjects';
                teacherSubjects.name = 'subjects_disabled';
                course.required = true;
            } else {
                studentFields.classList.add('hidden');
                teacherFields.classList.remove('hidden');
                studentSubjects.name = 'subjects_disabled';
                teacherSubjects.name = 'subjects';
                course.required = false;
            }
        }
        // Initial call to set the correct fields on page load
        toggleFields();
    </script>
</body>
</html>

