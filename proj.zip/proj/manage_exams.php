<?php
// --- SESSION MANAGEMENT & AUTHENTICATION ---
session_start();
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

require_once 'db.php';
$success_message = '';
$error_message = '';

// Handle POST request to add a new exam entry
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_exam'])) {
    $subject = $conn->real_escape_string(trim($_POST['subject']));
    $exam_date = $conn->real_escape_string(trim($_POST['exam_date']));
    $start_time = $conn->real_escape_string(trim($_POST['start_time']));
    $location = $conn->real_escape_string(trim($_POST['location']));
    $course = $conn->real_escape_string(trim($_POST['course'])); // Added course field

    if (empty($subject) || empty($exam_date) || empty($start_time) || empty($course)) {
        $error_message = "Please fill in all required fields.";
    } else {
        $teacher_id = $_SESSION['id'];
        $stmt = $conn->prepare("INSERT INTO exams (subject, exam_date, start_time, location, course, teacher_id) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssi", $subject, $exam_date, $start_time, $location, $course, $teacher_id);
        
        if ($stmt->execute()) {
            $success_message = "Exam added successfully!";
        } else {
            $error_message = "Error: Could not add exam.";
        }
        $stmt->close();
    }
}

// Handle GET request to delete an exam entry
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM exams WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    if($stmt->execute()){
        $success_message = "Exam deleted successfully!";
    } else {
        $error_message = "Error: Could not delete exam.";
    }
    $stmt->close();
}

// Fetch existing exam entries
$exams_result = $conn->query("SELECT * FROM exams ORDER BY exam_date ASC, start_time ASC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Exams - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100">
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
             <a href="dashboard.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
            <a href="dashboard.php" class="text-sm font-semibold text-indigo-600 hover:underline">← Back to Dashboard</a>
        </div>
    </header>

    <main class="container mx-auto px-6 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Manage Exams</h1>
        
        <?php if ($success_message): ?><div class="bg-green-100 text-green-700 p-3 rounded-md mb-4"><?php echo $success_message; ?></div><?php endif; ?>
        <?php if ($error_message): ?><div class="bg-red-100 text-red-700 p-3 rounded-md mb-4"><?php echo $error_message; ?></div><?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Add Exam Form -->
            <div class="lg:col-span-1 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Add New Exam</h2>
                <form action="manage_exams.php" method="POST" class="space-y-4">
                    <div>
                        <label for="course" class="block text-sm font-medium text-gray-700">Course</label>
                        <input type="text" id="course" name="course" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md" placeholder="e.g., Computer Science">
                    </div>
                    <div>
                        <label for="subject" class="block text-sm font-medium text-gray-700">Subject</label>
                        <input type="text" id="subject" name="subject" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md" placeholder="e.g., Final Theory Exam">
                    </div>
                     <div>
                        <label for="exam_date" class="block text-sm font-medium text-gray-700">Date</label>
                        <input type="date" id="exam_date" name="exam_date" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label for="start_time" class="block text-sm font-medium text-gray-700">Start Time</label>
                        <input type="time" id="start_time" name="start_time" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label for="location" class="block text-sm font-medium text-gray-700">Location/Room</label>
                        <input type="text" id="location" name="location" class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md" placeholder="e.g., Exam Hall B">
                    </div>
                    <button type="submit" name="add_exam" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md">Add Exam</button>
                </form>
            </div>

            <!-- Existing Exams -->
            <div class="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Scheduled Exams</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Date</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Time</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Course</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Subject</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Location</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if ($exams_result && $exams_result->num_rows > 0): ?>
                                <?php while($row = $exams_result->fetch_assoc()): ?>
                                    <tr>
                                        <td class="px-4 py-3 font-medium text-gray-900"><?php echo date('M j, Y', strtotime($row['exam_date'])); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo date('g:i A', strtotime($row['start_time'])); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo htmlspecialchars($row['course']); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo htmlspecialchars($row['subject']); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo htmlspecialchars($row['location']); ?></td>
                                        <td class="px-4 py-3 text-sm font-medium">
                                            <a href="manage_exams.php?delete_id=<?php echo $row['id']; ?>" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure you want to delete this exam?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="px-4 py-3 text-center text-gray-500">No exams have been scheduled.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>

