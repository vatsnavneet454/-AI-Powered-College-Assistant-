<?php
// --- SESSION MANAGEMENT & AUTHENTICATION ---
session_start();
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

require_once 'db.php';
$success_message = '';
$error_message = '';

// Handle POST request to add a new timetable entry
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_schedule'])) {
    $class_name = $conn->real_escape_string(trim($_POST['class_name']));
    $day_of_week = $conn->real_escape_string(trim($_POST['day_of_week']));
    $start_time = $conn->real_escape_string(trim($_POST['start_time']));
    $end_time = $conn->real_escape_string(trim($_POST['end_time']));
    $subject = $conn->real_escape_string(trim($_POST['subject']));
    $faculty_id = (int)$_POST['faculty_id'];
    $location = $conn->real_escape_string(trim($_POST['location']));

    if (empty($class_name) || empty($day_of_week) || empty($start_time) || empty($end_time) || empty($subject)) {
        $error_message = "Please fill in all required fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO timetables (class_name, day_of_week, start_time, end_time, subject, faculty_id, location) VALUES (?, ?, ?, ?, ?, ?, ?)");
        // Use "i" for integer faculty_id, or NULL if it's 0
        $faculty_id_to_insert = ($faculty_id > 0) ? $faculty_id : NULL;
        $stmt->bind_param("sssssis", $class_name, $day_of_week, $start_time, $end_time, $subject, $faculty_id_to_insert, $location);
        
        if ($stmt->execute()) {
            $success_message = "Schedule added successfully!";
        } else {
            $error_message = "Error: Could not add schedule.";
        }
        $stmt->close();
    }
}

// Handle GET request to delete a schedule entry
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM timetables WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    if($stmt->execute()){
        $success_message = "Schedule deleted successfully!";
    } else {
        $error_message = "Error: Could not delete schedule.";
    }
    $stmt->close();
}


// Fetch all faculty members for the dropdown
$faculty_result = $conn->query("SELECT id, name FROM faculty ORDER BY name ASC");

// Fetch existing timetable entries, joining with faculty to get names
$timetable_query = "
    SELECT t.*, f.name as faculty_name 
    FROM timetables t
    LEFT JOIN faculty f ON t.faculty_id = f.id
    ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), t.start_time ASC
";
$timetable_result = $conn->query($timetable_query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Timetable - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100">
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
             <a href="dashboard.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
            <a href="dashboard.php" class="text-sm font-semibold text-indigo-600 hover:underline">← Back to Dashboard</a>
        </div>
    </header>

    <main class="container mx-auto px-6 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Manage Class Timetable</h1>
        
        <?php if ($success_message): ?><div class="bg-green-100 text-green-700 p-3 rounded-md mb-4"><?php echo $success_message; ?></div><?php endif; ?>
        <?php if ($error_message): ?><div class="bg-red-100 text-red-700 p-3 rounded-md mb-4"><?php echo $error_message; ?></div><?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Add Schedule Form -->
            <div class="lg:col-span-1 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Add New Schedule</h2>
                <form action="manage_timetable.php" method="POST" class="space-y-4">
                    <div>
                        <label for="class_name" class="block text-sm font-medium text-gray-700">Class/Course Name</label>
                        <input type="text" id="class_name" name="class_name" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md" placeholder="e.g., Computer Science Sem 3">
                    </div>
                    <div>
                        <label for="day_of_week" class="block text-sm font-medium text-gray-700">Day of the Week</label>
                        <select id="day_of_week" name="day_of_week" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                            <option>Monday</option>
                            <option>Tuesday</option>
                            <option>Wednesday</option>
                            <option>Thursday</option>
                            <option>Friday</option>
                            <option>Saturday</option>
                            <option>Sunday</option>
                        </select>
                    </div>
                     <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label for="start_time" class="block text-sm font-medium text-gray-700">Start Time</label>
                            <input type="time" id="start_time" name="start_time" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                        </div>
                        <div>
                            <label for="end_time" class="block text-sm font-medium text-gray-700">End Time</label>
                            <input type="time" id="end_time" name="end_time" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                        </div>
                    </div>
                    <div>
                        <label for="subject" class="block text-sm font-medium text-gray-700">Subject</label>
                        <input type="text" id="subject" name="subject" required class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md" placeholder="e.g., Database Systems">
                    </div>
                    <div>
                        <label for="faculty_id" class="block text-sm font-medium text-gray-700">Assign Faculty</label>
                        <select id="faculty_id" name="faculty_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md">
                            <option value="0">None</option>
                            <?php if ($faculty_result->num_rows > 0): ?>
                                <?php while($faculty = $faculty_result->fetch_assoc()): ?>
                                    <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div>
                        <label for="location" class="block text-sm font-medium text-gray-700">Location/Room</label>
                        <input type="text" id="location" name="location" class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md" placeholder="e.g., Room C-301">
                    </div>
                    <button type="submit" name="add_schedule" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md">Add to Timetable</button>
                </form>
            </div>

            <!-- Existing Timetable -->
            <div class="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Current Timetable</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Day</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Time</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Subject</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Class</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Faculty</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if ($timetable_result && $timetable_result->num_rows > 0): ?>
                                <?php while($row = $timetable_result->fetch_assoc()): ?>
                                    <tr>
                                        <td class="px-4 py-3 font-medium text-gray-900"><?php echo htmlspecialchars($row['day_of_week']); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo date('g:i A', strtotime($row['start_time'])) . ' - ' . date('g:i A', strtotime($row['end_time'])); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-700"><?php echo htmlspecialchars($row['subject']); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo htmlspecialchars($row['class_name']); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo $row['faculty_name'] ? htmlspecialchars($row['faculty_name']) : 'N/A'; ?></td>
                                        <td class="px-4 py-3 text-sm font-medium">
                                            <a href="manage_timetable.php?delete_id=<?php echo $row['id']; ?>" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure you want to delete this schedule?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="px-4 py-3 text-center text-gray-500">The timetable is empty.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>

