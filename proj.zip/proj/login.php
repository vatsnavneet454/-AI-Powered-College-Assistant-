<?php
// --- SESSION MANAGEMENT ---
session_start();

// Redirect if already logged in
if (isset($_SESSION['id'])) {
    header("Location: dashboard.php");
    exit();
}

// --- INCLUDE DATABASE CONNECTION ---
require_once 'db.php';

// --- VARIABLE INITIALIZATION ---
$login_identifier = "";
$password = "";
$error_message = "";

// --- FORM SUBMISSION HANDLING ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- INPUT VALIDATION ---
    if (empty(trim($_POST["login_identifier"]))) {
        $error_message = "Please enter your email or registration ID.";
    } else {
        $login_identifier = trim($_POST["login_identifier"]);
    }

    if (empty(trim($_POST["password"]))) {
        $error_message = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // --- DATABASE QUERY ---
    if (empty($error_message)) {
        // Query to find the user by either email or registration_id
        $sql = "SELECT id, name, email, password, role, course, subjects FROM users WHERE email = ? OR registration_id = ?";

        if ($stmt = $conn->prepare($sql)) {
            // Bind the identifier to both placeholders for the OR condition
            $stmt->bind_param("ss", $login_identifier, $login_identifier);

            if ($stmt->execute()) {
                $stmt->store_result();

                if ($stmt->num_rows == 1) {
                    // Bind result variables
                    $stmt->bind_result($id, $name, $email, $hashed_password, $role, $course, $subjects);
                    
                    if ($stmt->fetch()) {
                        // Verify password
                        if (password_verify($password, $hashed_password)) {
                            // --- SESSION CREATION ---
                            // Password is correct, start a new session
                            session_start();
                            
                            // Store all relevant user data in the session
                            $_SESSION["id"] = $id;
                            $_SESSION["name"] = $name;
                            $_SESSION["email"] = $email;
                            $_SESSION["role"] = $role;
                            $_SESSION["course"] = $course;
                            $_SESSION["subjects"] = $subjects;
                            
                            // Redirect to the dashboard
                            header("location: dashboard.php");
                            exit();
                        } else {
                            $error_message = "Invalid credentials. Please check your details and try again.";
                        }
                    }
                } else {
                    $error_message = "No account found with that email or registration ID.";
                }
            } else {
                $error_message = "Oops! Something went wrong. Please try again later.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CampusConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100">
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4">
            <a href="index.php" class="text-2xl font-bold text-gray-800">Campus<span class="text-indigo-600">Connect</span></a>
        </nav>
    </header>

    <main class="flex justify-center items-center min-h-screen" style="margin-top: -80px;">
        <div class="w-full max-w-md bg-white p-8 rounded-lg shadow-md">
            <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Welcome Back!</h2>
            
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-4" role="alert">
                    <span><?php echo $error_message; ?></span>
                </div>
            <?php endif; ?>

            <form action="login.php" method="POST" class="space-y-6">
                <div>
                    <label for="login_identifier" class="block text-sm font-medium text-gray-700">Email or Registration ID</label>
                    <input type="text" id="login_identifier" name="login_identifier" required
                           class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                           value="<?php echo htmlspecialchars($login_identifier); ?>">
                </div>
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" id="password" name="password" required
                           class="mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                </div>
                <div>
                    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-md transition duration-300">
                        Sign In
                    </button>
                </div>
            </form>
            
            <p class="text-center text-gray-600 text-sm mt-6">
                Don't have an account? 
                <a href="signup.php" class="font-bold text-indigo-600 hover:text-indigo-800">
                    Sign up now
                </a>
            </p>
        </div>
    </main>
</body>
</html>

